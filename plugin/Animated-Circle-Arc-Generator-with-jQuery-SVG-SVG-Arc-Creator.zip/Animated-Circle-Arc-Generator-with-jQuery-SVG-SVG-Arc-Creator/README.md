jQuery SVG arc creator
======================

This scripts allows you to create SVG arcs/circles by scripting. It also allows you to create circular loading animations by setting a simple timeout.
